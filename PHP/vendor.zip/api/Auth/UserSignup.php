
<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header('Content-Type: application/json');

require_once(__DIR__ . '/../../config/Database.php');
require_once(__DIR__ . '/../../assets/controllers/Signup.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $controller = new App\Controllers\SignupController();

    // if (isset($_POST['role']) && $_POST['role'] === 'user') {
        $controller->handleSignup();
        exit;
    // } 
    
} else {
    header("HTTP/1.1 405 Method Not Allowed");
}