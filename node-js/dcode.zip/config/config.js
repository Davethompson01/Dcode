module.exports = {
    // api1Url: 'https://api.example.com/endpoint1',
    // api2Url: 'https://',
    phpServiceUrl: 'http://localhost/D_code/PHP/api/Auth/login.php'  
};
