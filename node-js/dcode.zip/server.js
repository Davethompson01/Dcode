const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

// Import your routes
const productRoutes = require("./assets/routes/product");
const signupRoutes = require("./assets/routes/signup");
const orderRoutes = require("./assets/routes/order");
const loginRoute = require("./assets/routes/login");

const app = express();

// Use middleware
app.use(cors()); // Allow all origins; configure if necessary
app.use(bodyParser.json()); // Parse JSON bodies

// Define your API routes
app.use("/", productRoutes); // Product routes
app.use("/", signupRoutes); // Signup routes
app.use("/", orderRoutes); // Order routes
app.use("/", loginRoute);

// Set the port
const PORT = process.env.PORT || 3000;

// Start the server
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
