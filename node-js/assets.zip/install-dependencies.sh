#!/bin/bash
cd /public_html/D_code/node-js/api
npm install

cd /public_html/D_code/node-js/package.json
npm install
